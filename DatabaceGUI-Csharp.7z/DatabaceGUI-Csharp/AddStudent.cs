﻿using System;
using System.Windows.Forms;

using MySql.Data.MySqlClient;

namespace DatabaceGUI_Csharp
{
    public partial class AddStudent : Form
    {
        public AddStudent()
        {
            InitializeComponent();
        }

        private void GroupBox1_Enter(object sender, EventArgs e)
        {

        }
        private void Button1_Click(object sender, EventArgs e)
        {
            var constring = "datasource=localhost;port=3306;username=root;password=EM@#!!e8e86six";
            var Query = "insert into software_proj.students_table (Student_ID,First_Name,Last_Name) values ('" + id_txt.Text + "','" + Fname_txt.Text + "','" + Lname_txt.Text + "') ;";
            MySqlConnection conDataBase = new MySqlConnection(constring);
            MySqlDataReader myReader;
            try
            {
                conDataBase.Open();
                using MySqlCommand cmdDataBase = new MySqlCommand(Query, conDataBase);
                myReader = cmdDataBase.ExecuteReader();
                MessageBox.Show("Saved");
                while (myReader.Read())
                {

                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }



        }

        private void Button1_Click_1(object sender, EventArgs e)
        {
            var constring = "datasource=localhost;port=3306;username=root;password=EM@#!!e8e86six";
            var Query = "update software_proj.students_table set Student_ID = '" + id_txt.Text + "' ,First_Name = '" + Fname_txt.Text + "',Last_Name ='" + Lname_txt.Text + "' where Student_ID = '" + id_txt.Text+ "' ;";
            MySqlConnection conDataBase = new MySqlConnection(constring);
            MySqlCommand cmdDataBase = new MySqlCommand(Query, conDataBase);
            MySqlDataReader myReader;
            try
            {
                conDataBase.Open();
                myReader = cmdDataBase.ExecuteReader();
                MessageBox.Show("Saved");
                while (myReader.Read())
                {

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Random rnd = new Random();
            id_txt.Text = rnd.Next(1000000,9999999).ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            var constring = "datasource=localhost;port=3306;username=root;password=EM@#!!e8e86six";
            var Query = "delete from software_proj.students_table where Student_ID = '" + id_txt.Text + "' ;";
            MySqlConnection conDataBase = new MySqlConnection(constring);
            MySqlCommand cmdDataBase = new MySqlCommand(Query, conDataBase);
            MySqlDataReader myReader;
            try
            {
                conDataBase.Open();
                myReader = cmdDataBase.ExecuteReader();
                MessageBox.Show("Deleted");
                while (myReader.Read())
                {

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
