﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DatabaceGUI_Csharp
{
    public partial class student_Search : Form
    {
        public student_Search()
        {
            InitializeComponent();
        }

        private void Student_Search_Load(object sender, EventArgs e)
        {

        }
    }
}
