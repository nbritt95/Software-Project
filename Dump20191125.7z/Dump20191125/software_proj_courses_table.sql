-- MySQL dump 10.13  Distrib 8.0.18, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: software_proj
-- ------------------------------------------------------
-- Server version	8.0.18

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `courses_table`
--

DROP TABLE IF EXISTS `courses_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `courses_table` (
  `Course_ID` int(12) NOT NULL,
  `Course_Number` int(11) NOT NULL,
  `Course_Name` varchar(45) NOT NULL,
  `Start_Time` varchar(45) NOT NULL,
  `End_Time` varchar(45) NOT NULL,
  `Course_Days` varchar(45) NOT NULL,
  `Professor_Name` varchar(45) NOT NULL,
  PRIMARY KEY (`Course_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `courses_table`
--

LOCK TABLES `courses_table` WRITE;
/*!40000 ALTER TABLE `courses_table` DISABLE KEYS */;
INSERT INTO `courses_table` VALUES (1,1000,'COMM','8:00','9:15','T/TH','Ms.Guadalupe'),(2,2000,'MATH','14:00','15:15','M/W','Mr.Abbot'),(3,3000,'CS','8:00','10:15','F','Dr.Howard'),(4,4000,'POLS','16:00','17:15','TH','Mrs.Wetherell'),(5,5000,'TCOMM','12:45','1:15','T','Mr.Mackenzie'),(6,6000,'STAT','10:30','12:45','M','Dr.Carlow'),(7,7000,'ENG','9:00','10:15','T/TH','Mrs.Nern'),(8,8000,'ART','9:30','11:15','M/W','Ms.Phetteplace'),(9,9000,'PHIL','17:30','18:45','M/W','Dr.Wiley'),(10,10000,'SOS','11:00','12:15','S','Mr.Alderson');
/*!40000 ALTER TABLE `courses_table` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-11-25 21:20:55
